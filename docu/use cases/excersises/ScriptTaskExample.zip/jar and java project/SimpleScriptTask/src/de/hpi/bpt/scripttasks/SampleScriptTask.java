package de.hpi.bpt.scripttasks;

import bpt.chimera.scripttasklibrary.IChimeraContext;
import bpt.chimera.scripttasklibrary.IChimeraDelegate;

public class SampleScriptTask implements IChimeraDelegate {

    @Override
    public void execute(IChimeraContext context) {
        // insert code here
        context.log("It worked!");
    }

}
